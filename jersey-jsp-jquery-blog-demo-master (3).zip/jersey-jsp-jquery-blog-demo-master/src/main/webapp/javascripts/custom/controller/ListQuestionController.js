function ListQuestionController($scope, $window) {
	$scope.data = "<%= locals.data || '' %>";
}