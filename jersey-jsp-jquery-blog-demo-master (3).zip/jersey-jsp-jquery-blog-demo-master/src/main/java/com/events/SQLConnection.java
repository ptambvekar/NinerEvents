package com.events;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;  

@WebServlet("/yourServletURL")
public class SQLConnection extends HttpServlet{  
	
		  public void doPost(HttpServletRequest req, 
		  HttpServletResponse res) throws ServletException,
		  IOException{
		  String connectionURL = "jdbc:mysql://localhost:3306/ssdieventmanagement";
		  Connection connection=null;
		  ResultSet rs;
		  res.setContentType("text/html");
		  PrintWriter out = res.getWriter();
		
		  String event_name = req.getParameter("event_name");
		  
		  try {
		  
		  Class.forName("org.gjt.mm.mysql.Driver");
		
		  connection = DriverManager.getConnection(connectionURL, "root", ""); 
		  
		  if (connection != null) {
				System.out.println("You made it, take control your database now!");
			} else {
				System.out.println("Failed to make connection!");
			}
		  
		  String sql = "insert into event(event_name) values (?)";
		  PreparedStatement pst = connection.prepareStatement(sql);
		  pst.setString(1, event_name);
		
		  int numRowsChanged = pst.executeUpdate();
		
		  out.println(" '"+event_name+"'");
		  pst.close();
		  }
		  catch(ClassNotFoundException e){
		  out.println("Couldn't load database driver: " + e.getMessage());
		  }
		  catch(SQLException e){
		  out.println("SQLException caught: " + e.getMessage());
		  }
		  catch (Exception e){
		  out.println(e);
		  }
		  finally {
		
		  try {
		  if (connection != null) connection.close();
		  }
		  catch (SQLException ignore){
		  out.println(ignore);
		  }
		  }
		  }
        
    
}
