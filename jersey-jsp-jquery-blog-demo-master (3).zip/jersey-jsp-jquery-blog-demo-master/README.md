# jersey-jsp-jquery-blog-demo
jersey-jsp-jquery-blog-demo

This is a demo project aims to integrate below techonoliges together easily:

1. Jersey REST service
2. Jsp
3. Jquery
4. Bootstrap

Setup guide:<br>
1. git clone https://github.com/jimuyouyou/jersey-jsp-jquery-blog-demo.git<br>
2. mv jersey-jsp-jquery-blog-demo jersey-rest<br>
3. cd jersey-rest/<br>
4. mvn clean compile<br>
5. mvn eclipse:eclipse<br>
6. Eclipse > Import as existing maven project<br>
7. Right click on your project and Run on Server<br>
8. http://localhost:8080/jersey-rest/<br>

screenshot:<p>
<img src='screenshot.jpg'/>








